from django.apps import AppConfig


class CvdPortalConfig(AppConfig):
    name = 'cvd_portal'
