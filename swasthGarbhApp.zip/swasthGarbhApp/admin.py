# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from swasthGarbhApp.models import *
from django.contrib import admin

admin.site.register(Medicine)
admin.site.register(Hospital)
admin.site.register(Complication)
admin.site.register(PregnancyData)
# Register your models here.
